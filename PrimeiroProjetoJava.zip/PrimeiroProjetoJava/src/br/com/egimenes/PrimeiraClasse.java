package br.com.egimenes;

public class PrimeiraClasse {

	public static void main(String[] args) {
	System.out.print("Oi Eric");
	}
}